-------------------------------------------------------------------------------------------------------
Programa que faz a leitura uma base de dados e a lista de diversas formas dependendo da pesquisa feita.

	1 - modificar banco de dados
	2 - imprimir todos os dados.
	3 - mudar como os dados sao ordenados.
	4 - fazer uma pesquisa.
	5 - modificar os itens listados.
	6 - pesquisar variacao por intervalo.
	outro para finalizar.

-------------------------------------------------------------------------------------------------------
